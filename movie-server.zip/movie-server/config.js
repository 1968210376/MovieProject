//向外共享加密和还原 Token 的 jwtSecretKey 字符串
module.exports = {
    //加密解密Token的密匙
    jwtSecretKey:'Mr.D ^~^ ',
    //token 有效期
    expiresIn:'10h',
    
}