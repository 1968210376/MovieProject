# movies-server

## 启动

```bash
# 启动命令
node app.js

```
